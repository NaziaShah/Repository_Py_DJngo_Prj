from django.dispatch import Signal


# Generated file signals
content_required = Signal()
existence_required = Signal()

# Source group signals
source_saved = Signal()
