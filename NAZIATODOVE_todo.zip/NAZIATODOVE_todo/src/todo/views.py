from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.views.generic import View
from .models import Todo

class views(View):
    model = Todo
    #template_name = 'index.html'

	def index(request):
	    todos = Todo.objects.all()[1:15]

	    context = {
	        'todos':todos
	    }
	    return render(request, 'index.html', context)

	def info(request, id):
	    todo = Todo.objects.get(id=id)

	    context = {
	        'todo':todo
	    }
	    return render(request, 'info.html', context)

	def new(request):
	    if(request.method == 'POST'):
	        title = request.POST['title']
	        text = request.POST['text']

	        todo = Todo(title=title, text=text)
	        todo.save()

	        return redirect('/todos')
	    else:
	        return render(request, 'new.html')