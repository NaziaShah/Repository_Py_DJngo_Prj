#from django.shortcuts import render
import datetime
import re

from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.http import Http404
from django.views.generic import date_based, list_detail
from django.db.models import Q
from django.conf import settings

from blogs.models import *

# Create your views here.
#def home(request):
	#context = locals()
	#template = 'home.html'
	#return render(request,template,context)


def display_list(request, page=0, paginate_by=20, **kwargs):
    page_size = getattr(settings,'BLOG_PAGESIZE', paginate_by)
    return list_detail.object_list(
        request,
        queryset=Display.objects.published(),
        paginate_by=page_size,
        page=page,
        **kwargs
    )
display_list.__doc__ = list_detail.object_list.__doc__

def category_list(request, template_name = 'blog/category_list.html', **kwargs):
    """
    Category list
    Template: ``blog/category_list.html``
    Context:
        object_list
            List of categories.
    """
    return list_detail.object_list(
        request,
        queryset=Category.objects.all(),
        template_name=template_name,
        **kwargs
    )


