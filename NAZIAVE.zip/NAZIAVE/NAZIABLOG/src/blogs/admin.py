from django.contrib import admin

# Register your models here.
from .models import *

class CategoryAdmin(admin.ModelAdmin):
	#class Meta:
		#model = Category
	prepopulated_fields = {'slug': ('title',)}
admin.site.register(Category,CategoryAdmin)


