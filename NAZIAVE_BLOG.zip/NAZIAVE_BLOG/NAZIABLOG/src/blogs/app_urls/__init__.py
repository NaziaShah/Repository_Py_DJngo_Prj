from django.conf.urls import url

from blogs.views import views

urlpatterns = [
    url(r'^$', views.as_view(), name='blog-home'),
]