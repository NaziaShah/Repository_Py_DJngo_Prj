#from django.shortcuts import render
import datetime
import re
from django.shortcuts import render_to_response, get_object_or_404
from django.template import Context
from django.http import Http404
from django.views.generic import View
from django.db.models import Q
from django.conf import settings
from blogs.models import Category, Display


class views(View):
    model = Category
    template_name = 'category_list.html'


    def get(self, request, *args, **kwargs):
        self.object = self.get_queryset(request)
        context = Context({'category_list': self.object})
        return render_to_response(self.template_name, context)

    def get_queryset(self, request):
        category_list = self.model.objects.all()
        print ('category_list>>>', category_list)
        return category_list

