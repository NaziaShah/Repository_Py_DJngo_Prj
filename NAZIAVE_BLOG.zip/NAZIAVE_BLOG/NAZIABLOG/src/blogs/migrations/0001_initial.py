# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=100, verbose_name='title')),
                ('slug', models.SlugField(unique=True, verbose_name='slug')),
            ],
            options={
                'ordering': ('title',),
                'db_table': 'blog_categories',
                'verbose_name': 'category',
            },
        ),
        migrations.CreateModel(
            name='Display',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=200, verbose_name='title')),
                ('slug', models.SlugField(verbose_name='slug', unique_for_date='display')),
                ('body', models.TextField(verbose_name='body')),
                ('status', models.IntegerField(default=2, verbose_name='status', choices=[(1, 'Edited'), (2, 'Public mode')])),
                ('allow_comments', models.BooleanField(default=True, verbose_name='feedback')),
                ('display', models.DateTimeField(default=datetime.datetime.now, verbose_name='display')),
                ('created', models.DateTimeField(auto_now_add=True, verbose_name='started')),
                ('modified', models.DateTimeField(auto_now=True, verbose_name='Changes done')),
                ('author', models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True)),
                ('categories', models.ManyToManyField(to='blogs.Category', blank=True)),
            ],
            options={
                'ordering': ('-display',),
                'db_table': 'blog_displayBlogs',
                'verbose_name': 'displayBlog',
                'get_latest_by': 'display',
            },
        ),
    ]
