from __future__ import unicode_literals
from django.utils.translation import ugettext_lazy as _
from django.db import models
from django.contrib.auth.models import User
from django.db.models import permalink
from django.conf import settings
import datetime

# Create your models here.
#class blog(models.Model):
	#name = models.CharField(max_length=120)
	#description = models.TextField(default='description default text')
	#location = models.CharField(max_length=110,default='my location default',blank='True',null = 'True')
	#job = models.CharField(max_length=100, null=True)

	#def __unicode__(self):
		#return self.name	
		#return self.description

class Category(models.Model):
    """Category model."""
    title = models.CharField(_('title'), max_length=100)
    description=models.TextField(default='description default')
    #bodytext = models.TextField(verbose_name=_("message"))
    #slug = models.SlugField(_('slug'), unique=True)

    class Meta:
        verbose_name = _('category')
        db_table = 'blog_categories'
        ordering = ('title',)

    def __unicode__(self):
        return '%s' % self.title
        return self.description

    """@permalink
    def get_url(self):
        return ('blog_categoryinfo', None, {'slug': self.slug})"""

class Display(models.Model):
    """Display model."""
    CHOICES = (
        (1, _('Edited')),
        (2, _('Public mode')),
    )
    title = models.CharField(_('title'), max_length=200)
    #slug = models.SlugField(_('slug'), unique_for_date='display')
    author = models.ForeignKey(User, blank=True, null=True)
    body = models.TextField(_('body'), )
    status = models.IntegerField(_('status'), choices=CHOICES, default=2)
    allow_comments = models.BooleanField(_('feedback'), default=True)
    display = models.DateTimeField(_('display'), default=datetime.datetime.now)
    created = models.DateTimeField(_('started'), auto_now_add=True)
    modified = models.DateTimeField(_('Changes done'), auto_now=True)
    categories = models.ManyToManyField(Category, blank=True)
   

    class Meta:
        verbose_name = _('displayBlog')
        db_table  = 'blog_displayBlogs'
        ordering  = ('-display',)
        get_latest_by = 'display'

    def __unicode__(self):
        return u'%s' % self.title

    @permalink
    def get_url(self):
        return ('blog_detail', None, {
            'year': self.displayyear,
            'month': self.display.strftime('%b').lower(),
            'day': self.display.day,
            #'slug': self.slug
        })

