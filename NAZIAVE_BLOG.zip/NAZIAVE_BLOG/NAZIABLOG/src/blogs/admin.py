from django.contrib import admin

# Register your models here.
from blogs.models import Category, Display


admin.site.register(Category)