# Rep_Py_Proj
This repository contains sample pieces of Python &amp; Django.
